<?php 
echo phpinfo() 
?>