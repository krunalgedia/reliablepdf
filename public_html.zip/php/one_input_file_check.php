<?php
if($num_files>1){
    echo '<script type="text/javascript">alert("Please choose one file at a time!")</script>';
    $uploadOk = 0;
    exit;
}
?>
