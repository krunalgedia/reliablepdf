<?php

#$zip = new ZipArchive;
#$zip->open($zipfolderlocation, ZipArchive::CREATE);
#echo "base aname os : ";
#$globpath =  str_replace(".zip","*.png",basename($zipfolderlocation));
#echo $globpath;
#echo gettype(str_replace(".zip","*.png",basename($zipfolderlocation)));
#echo "<br>";
#echo glob(str_replace(".zip","*.png",basename($zipfolderlocation)));
#$abc = "phpE3B1*.png";

#foreach (glob($globpath) as $i){
    #copy($i,$i);
#    $zip->addFile($i);
#    echo $i." adding this works <br>";
#}
#$zip->close();
?>