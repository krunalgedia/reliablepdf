var adblockDetecter = false;
console.log(adblockDetecter);